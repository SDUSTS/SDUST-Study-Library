int dgy(int,int);
int xgb(int m,int n);
