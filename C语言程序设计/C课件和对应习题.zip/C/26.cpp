#include <stdio.h>
void strconn(char a[],char b[]);
int main(){
	char str1[100]="hello ",str2[100]="world";
	strconn(str1,str2);
	printf("%s",str1);
}
void strconn(char a[],char b[]){
	char *p,*q;
	p=a;
	q=b;	
	while(*p!='\0'){
		p++;
	}
	while(*q!='\0'){
		*p=*q;
		p++;
		q++;
	}
	*p='\0';	
}
