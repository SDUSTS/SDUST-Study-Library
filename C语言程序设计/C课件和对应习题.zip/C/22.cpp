#include <stdio.h>
int main(){
	char str1[100]="hello world",str2[100]="hello world";
	char *p,*q;
	p=str1;
	q=str2;
	while(*p!='\0'){
		if(*p==*q){
			p++;
			q++;
		}else{
			break;
		}
	}
	if(*p=='\0'&&*q=='\0'){
		printf("yes");
	}else{
		printf("no");
	}
	
}
