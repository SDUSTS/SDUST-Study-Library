#include <stdio.h>
#include <ctype.h> 
int main(){
	char c='a';
	printf("%c\n",c);
	printf("%d\n",c);	
	printf("%d",isupper(c));
}
