#include <stdio.h>
void printarray(int m[],int len);
void xzsort(int m[],int len);

int main(){
	int b[8]={7,3,4,8,2,9,5,6};
	xzsort(b,8);
	printarray(b,8);
}
void xzsort(int a[],int len){
	for(int i=0;i<len-1;i++){
		for(int j=i+1;j<len;j++){
			if(a[j]<a[i]){
				int m=a[i];
				a[i]=a[j];
				a[j]=m;
			}
		}	
	}	
}
void printarray(int m[],int len){
   	for(int i=0;i<len;i++){
		printf("%d  ",m[i]);		
	}
	printf("\n");	
}

