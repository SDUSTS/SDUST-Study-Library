#include <stdio.h>
int fbs();
int main(){
	int x;
	x=fbs(); 
	printf("%d\n",x);
	
	x=fbs(); 
	printf("%d\n",x);
	
	x=fbs(); 
	printf("%d\n",x);	
	x=m;
}
int fbs(){
	static int m=1;
	m=m+1;
	return m;
}
