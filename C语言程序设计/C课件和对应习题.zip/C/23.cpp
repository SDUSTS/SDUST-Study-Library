#include <stdio.h>
int main(){
	char str1[100];
	scanf("%s",str1);
	
	char *p,*q;
	p=q=str1;	
	while(*q!='\0'){
		q++;
	}
	q--;	
	while(*p!='\0'){
		if(*p==*q){
			p++;
			q--;
		}else{
			break;
		}
	}
   if(*p=='\0'){
   	 printf("yes");
   }else{
   	  printf("no");
   }
}
	
	
