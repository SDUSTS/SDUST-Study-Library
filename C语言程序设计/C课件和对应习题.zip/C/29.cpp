#include <stdio.h>
char* nz(char t[]);
int main(){
	char str[100]="abcdefghijk";
			
	printf("%s\n",nz(str));
}
char* nz(char s[]){
    char *p,*q;
	p=s;
	q=s;
	while(*q!='\0'){
		q++;
	}
	q--;
	while(p<q){
		char c;
		c=*p;
		*p=*q;
		*q=c;
		p++;
		q--;
	}
	return s;	
}
