#include <stdio.h>
int main(){
	int x[5]={19,3,15,7,11};
	
	printf("%d\n",x);
	printf("%p",x);

//	for(int i=0;i<5;i++){
//		printf("%7d%10d%5s",i,x[i]," ");
//		for(int j=1;j<=x[i];j++){
//			printf("*");
//		}
//		printf("\n");
//	}	
}
