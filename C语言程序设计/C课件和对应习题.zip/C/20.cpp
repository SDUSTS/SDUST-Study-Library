
#include <stdio.h>
int main(){
	char str1[100],str2[100];
	scanf("%s",str1);
	char *p,*q;
	p=str1;
	q=str2;
	while(*p!='\0'){
		*q=*p;
		q++;
		p++;		
	}
	*q='\0';
  printf("%s\n",str2);
}

	
	
	
	
