#include <stdio.h>

int main(){
	int a[40]={2,2,3,4,5,3,8,9,6,9,7,8,6,4,3,10,1,3,2,4,6,2,3,4,5,3,8,9,6,10,7,8,6,4,3,10,1,3,2,4};
    int min;
    min=a[0];
    for(int i=1;i<40;i++){
    	if (a[i]<min){
    		min=a[i];
		}
	}
	printf("min=%d",min);   
}
