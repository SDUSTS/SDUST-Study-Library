#include <stdio.h>
void f(const int m[],int size){
    for(int i=0;i<size;i++){
	   m[i]=m[i]*2;
	}
}
void f1(int m){
	m=m*2;
}
void printarray(int m[],int len){
   	for(int i=0;i<len;i++){
		printf("%d  ",m[i]);		
	}
	printf("\n");	
}
int main(){
	int a[5]={1,2,3,4,5};
	printarray(a,5);
	f1(a[0]);
    printarray(a,5);
    f(a,5);
    printarray(a,5);
}
	
