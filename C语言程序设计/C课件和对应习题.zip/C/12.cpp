#include <stdio.h>
void printarray(int m[],int len);
int main(){
	int a[8]={7,3,4,8,2,9,5,6};
	for (int i=0;i<7;i++){	
		for(int j=0;j<7-i;j++){
			if(a[j]>a[j+1]){
				int m;
				m=a[j];
				a[j]=a[j+1];
				a[j+1]=m;
			}
		}
    }
	printarray(a,8);
}
void printarray(int m[],int len){
   	for(int i=0;i<len;i++){
		printf("%d  ",m[i]);		
	}
	printf("\n");	
}
	
