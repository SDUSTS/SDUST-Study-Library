#include <stdio.h>

int lenth(char b[]);

int main(){
	char str[100]="sdfsdafsadf";
	printf("%d",lenth(str));
}

int lenth(char a[]){
	char *p;
	p=a;
	int len=0;
	while(*p!='\0'){
		len++;
		p++;
	}
	return len;
}
