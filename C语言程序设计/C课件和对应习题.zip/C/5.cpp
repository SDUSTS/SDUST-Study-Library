#include <stdio.h>
#include <stdlib.h>

int main(){
	int seed;
	scanf("%d",&seed);
	srand(seed);	
	for(int i=1; i<=20;i++){
		int x=rand();
		x=x%6+1;
		printf("%10d",x);
		if(i%5==0){
			printf("\n");
		}		
	}	
}
