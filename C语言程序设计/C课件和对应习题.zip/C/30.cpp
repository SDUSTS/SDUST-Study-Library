#include <stdio.h>
int cz(int a[],int len,int key){
    int i=0,j=len-1,m;
	while(i<=j){
	   m=(i+j)/2;
	   if (key<a[m]){
	   	   j=m-1;
	   }else if(key>a[m]){
	   	   i=m+1;
	   }else{
	   	  return m;
	   }
    } 
   return -1;	
}
int main(){
	int a[10]={1,4,5,6,7,8,9,10,11,12};
	int k=3;
	printf("%d",cz(a,10,k));	
}
