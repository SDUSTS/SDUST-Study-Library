#include <stdio.h>
#include "gy.h"

int main(){
	int x,y;
	scanf("%d",&x);
	scanf("%d",&y);
	printf("max gong yue: %d\n",dgy(x,y));
	printf("min gong bei: %d\n",xgb(x,y));	
}

int dgy(int m,int n){
	int gy;
	for(int i=1;i<=m&&i<=n;i++){
		if(m%i==0&&n%i==0){
			gy=i;
		}
	}
	return gy;
}
int xgb(int m,int n){
	int gb;
	for(int i=m*n;i>=m&&i>=n;i--){
		if(i%m==0&&i%n==0){
			gb=i;
		}
	}
	return gb;
}
