#include <stdio.h>
void xzsort(int m[],int len);
int main(){
	int a[40]={2,2,3,4,5,3,8,9,6,9,7,8,6,4,3,10,1,3,2,4,6,2,3,4,5,3,8,9,6,10,7,8,6,4,3,10,1,3,2,4};
    xzsort(a,40);
    float k=(a[19]+a[20])/2.0;
    printf("median is %.1f",k);    
}

void xzsort(int a[],int len){
	for(int i=0;i<len-1;i++){
		for(int j=i+1;j<len;j++){
			if(a[j]<a[i]){
				int m=a[i];
				a[i]=a[j];
				a[j]=m;
			}
		}	
	}	
}
