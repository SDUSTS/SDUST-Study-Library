#include <stdio.h>

int main(){
	int a[40]={1,2,3,4,5,3,8,9,6,9,7,8,6,4,3,10,1,3,2,4,6,2,3,4,5,3,8,9,6,10,7,8,6,4,3,10,1,3,2,4};
    
	int s[11]={0};
    int i;
	for(i=0;i<40;i++){
		s[a[i]]++;
	}
	
	int j;	
	j=1;
	for(i=2;i<11;i++){
		if(s[j]<s[i]){			
			j=i;
		}
	}
	printf("j is %d, max is %d",j,s[j]);
}
