#include <stdio.h>

int main(){
	char str[100];
	scanf("%s",str);
	int i;
	for(i=0;i<100&&str[i]!='\0';i++){		
	}
	printf("%d",i);
	
	
//	char *p;
//	p=str;
//	int i=0;
//	while(*p!='\0'){
//		i++;
//		p++;
//	}
//	printf("%s\n",str);
//	printf("len=%d",i);
}
