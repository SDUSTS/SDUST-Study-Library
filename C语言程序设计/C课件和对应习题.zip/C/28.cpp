#include <stdio.h>
int main(){
	char str[100]="abcdefghijk";
	char *p,*q;
	p=str;
	q=str;
	while(*q!='\0'){
		q++;
	}
	q--;
	while(p<q){
		char c;
		c=*p;
		*p=*q;
		*q=c;
		p++;
		q--;
	}
	printf("%s\n",str);
}
