#include <stdio.h>

int linesearch(int m[],int len,int key);

int main(){
	int b[8]={7,3,4,8,2,9,5,6};
	int k= 8;
	printf(" the inex is %d",linesearch(b,8,k) );
}
int linesearch(int m[],int len,int key){
	for(int j=0;j<len;j++){
		if(m[j]==key){
			return j;
		}
	}
	return -1;
}
