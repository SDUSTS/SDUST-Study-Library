#include <stdio.h>
float mypow(float,int);
int main(){
	float x;
	int k;	

	printf("please input x and k:\n");
	
	scanf("%f",&x);
	scanf("%d",&k);			
	printf("x de k ci fang:",mypow(x,k));	
}

float mypow(float x,int m){
	float s=1;
	for(int i=1;i<=m;i++){
		s=s*x;
	}
    return s;	
}
