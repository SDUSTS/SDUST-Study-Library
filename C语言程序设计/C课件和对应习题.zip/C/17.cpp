#include <stdio.h>

int main(){
	int a[5]={2,4,5,7,8};
	int key=4;
	int i;
	for(i=0;i<5;i++){
		if (a[i]==key){
			break;
		}
	}
	for(;i<5-1;i++){
		a[i]=a[i+1];
	}
	for(i=0;i<4;i++){
		printf("%d  ",a[i]);
	}
}
