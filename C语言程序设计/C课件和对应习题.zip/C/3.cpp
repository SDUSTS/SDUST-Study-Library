#include <stdio.h>
int prime(int);
int main(){
  int m;
  scanf("%d",&m);
  if(prime(m)){
  	printf("is prime");
  }else{
  	printf(" is not  prime");
  }
}

int prime(int n){	
	for(int i=2;i<=n-1;i++){
		if(n%i==0){
		   return 0;	
		}
	}
	return 1;	
}

int prime2(int n){
    int pr=1;	
	for(int i=2;i<=n-1;i++){
		if(n%i==0){
		   pr=0;	
		}
	}
	return pr;	
}
int prime3(int n){
    int i;	
	for(i=2;i<=n-1;i++){
		if(n%i==0){
		   break;	
		}
	}
	if(i<n){
		return 0;
	}else{
		return 1;
	}	
}

