
#include <stdio.h>
int main(){
	int a[10],*p;
	int x=0;
	char c='d';
	printf("a len: %d\n",sizeof(a));
	printf("x len: %d\n",sizeof(x));
	printf("c len: %d\n",sizeof(c));
	
	p=a;
	printf("p=a len: %d\n",sizeof(*p));
	p=&x;
	printf("p=x len: %d\n",sizeof(*p));
}
	
	
	
	
