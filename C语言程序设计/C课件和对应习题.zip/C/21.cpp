#include <stdio.h>
int main(){
	char str1[100],str2[100]="char char";
	char *p,*q;
	p=str1;
	q=str2;
	while(*p!='\0'){
		p++;
	}
	while(*q!='\0'){
		*p=*q;
		p++;
		q++;
	}
	//*p='\0';
	printf("%s",str1);
}
	
	
