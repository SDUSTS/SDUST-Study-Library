#include <stdio.h>

int main(){
	int a[3][4]={{1,2,3,4},{5,6,7,8},{9,10,11,12}};
	int sum=0;
	for(int row=0;row<3;row++){
		for(int col=0;col<4;col++){
			sum=sum+a[row][col];
		}
	}
	printf("%d\n",sum);
	int h[4]={0};
	for(int row=0;row<3;row++){	
	    int s=0;	
		for(int col=0;col<4;col++){
		  printf("%d\t",a[row][col]);
		  s=s+a[row][col];
		  h[col]=h[col]+a[row][col];	
		}
		printf("%d\n",s);
	}
	for(int col=0;col<4;col++){
		printf("%d\t",h[col]);
	}
}
